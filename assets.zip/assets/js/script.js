$(document).ready(function() {
    
    //  ############################### EDIT ###################################  
    $('.edit_btn').click(function(){
        alert('success')
        var edit_mainid = $(this).attr("id");

        $.ajax({
                 url:"fetch.php",
                 method:"POST",
                 data:{edit_mainid:edit_mainid},
                 success:function(data){
                     $('#edit_admins').html(data)
                     $('#AdminEdit').modal("show");
                 }
        });        
        
    });
        // ######################################EDIT END ################################
        // $(document).on("click","#update_btn",function(){
        // //$('#update_btn').click(function(){
        //     alert('success')
        //     var update_mainid = $(this).attr("id");
    
        //     $.ajax({
        //              url:"update.php",
        //              method:"POST",
        //              data:{update_mainid:update_mainid},
        //              success:function(data){
        //                 $('#addadminform')[0].reset();
        //                 $('#AdminEdit').modal('hide');
        //                  $('#outputadd').html(data);
        //              }
        //     });        
            
        // });

        // ######################################UPDATE ################################
//    $('#update_btn').on('submit',function(event){
//        alert('success')
//      event.preventDefault();
//         if($('#editname1').val()=="")
//             {
//                 alert("Name is required");
//             }
//             else if($('#editemail01').val()=='')
//             {
//                 alert("Email is required");
//             }
//             else if($('#editpass01').val()=='')
//             {
//                 alert("Password is required");

//             }
//             else if($('#role').val()=='')
//             {
//                 alert("Role is required");

//             }
//             else if($('#adminstatus').val()=='')
//             {
//                 alert("Status is required");
//             }
//             else
//             {
//                 $.ajax({
//                     url:"update.php",
//                     method:"POST",
//                     data:$('#addadminform').serialize(),
//                     success:function(data)
//                     {
//                         $('#addadminform')[0].reset();
//                         $('#AdminEdit').modal('hide');
//                         $('#outputadd').html(data); 

//                     }
//                 })
//             }
//     });
              // ######################################UPDATE END ################################
  
               // ############################Add Admin ###########################
    $('#addadminform').on('submit',function(event){
        alert('success')
                
                event.preventDefault();
                if($('#addname1').val()=="")
            {
                alert("Name is required");
            }
            else if($('#addemail01').val()=='')
            {
                alert("Email is required");
            }
            else if($('#addpass01').val()=='')
            {
                alert("Password is required");

            }
            else if($('#role').val()=='')
            {
                alert("Role is required");

            }
            else if($('#adminstatus').val()=='')
            {
                alert("Status is required");
            }
            else
            {
                $.ajax({
                    url:"insert.php",
                    method:"POST",
                    data:$('#addadminform').serialize(),
                    success:function(data)
                    {
                        $('#addadminform')[0].reset();
                        $('#AddAdmin').modal('hide');
                        $('#outputadd').html(data); 

                    }
                })
            }
    });
                   // ##################################################################

});
