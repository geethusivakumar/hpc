document.getElementById("quizbtn").style.pointerEvents = "none";
document.getElementById("quizbtn").style.cursor = "default";

document.getElementById('videoid').addEventListener('ended', videoEndHandler, false);

function videoEndHandler(e) {
    document.getElementById("quizbtn").style.pointerEvents = "auto";
    document.getElementById("quizbtn").style.cursor = "pointer";
}