<?php
    include("__dbconnect.php");
    //$dbselect= mysqli_select_db($conn01,"test");
    $sqlsel1="select * from student";
    $result= mysqli_query($conn01,$sqlsel1);

    
?>
