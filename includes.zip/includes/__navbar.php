            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title" data-key="t-menu">Menu</li>

                            <li>
                                <a href="sadashboard">
                                    <i data-feather="home"></i>
                                    <span data-key="t-dashboard">Dashboard</span>
                                </a>
                            </li>

                            <li>
                                <a href="javascript: void(0);" class="has-arrow">
                                    <i data-feather="lock"></i>
                                    <span data-key="t-authentication">My Profile</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    
                                    <li><a href="sapassword"><i data-feather="key"></i>
                                    <span data-key="t-password">Change Password</span></a></li>
                                   
                                </ul>
                            </li>

                            <li>
                                <a href="saadmins" >
                                <i data-feather="users"></i>
                                    <span data-key="t-apps">Admins</span>
                                </a>
                                
                            </li>
                            <li>
                                <a href="javascript: void(0);" class="has-arrow">
                                    <i data-feather="users"></i>
                                    <span data-key="t-authentication">Users</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    
                                    <li><a href="view_employees"><i data-feather="user"></i>
                                    <span data-key="t-employee">Employee</span></a></li>
                                    <li><a href="view_customers"><i data-feather="user"></i>
                                    <span data-key="t-customer">Customer</span></a></li>                                   
                                </ul>
                            </li>
                            <li>
                                <a href="javascript: void(0);" class="has-arrow">
                                    <i data-feather="book"></i>
                                    <span data-key="t-courses">Courses</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    
                                    <li><a href="view_courses"><i data-feather="eye"></i>
                                    <span data-key="t-courses">View Courses</a></li>
                                    <li><a href="assignedemployees"><i data-feather="book"></i>
                                    <span data-key="t-ecourses">Courses Assigned to Employees</span></a></li>
                                    <li><a href="assignedcustomers"><i data-feather="book"></i>
                                    <span data-key="t-ccourses">Course Assigned to Customers</span></a></li>                                 
                                </ul>
                            </li>
                            <li>
                                <a href="userquizresults">
                                    <i data-feather="monitor"></i>
                                    <span data-key="t-quiz">Quiz results</span>
                                </a>
                            </li>
                            <li>
                                <a href="usercertificates">
                                    <i data-feather="monitor"></i>
                                    <span data-key="t-quiz">Certificates</span>
                                </a>
                            </li>

                            

                            <!-- <li class="menu-title mt-2" data-key="t-components">Elements</li> -->

                           
                        

                        </ul>


                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->