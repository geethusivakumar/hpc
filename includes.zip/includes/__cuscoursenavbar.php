            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title" data-key="t-menu">Menu</li>

                            <li>
                                <a href="customerdashboard">
                                    <i data-feather="home"></i>
                                    <span data-key="t-dashboard">Dashboard</span>
                                </a>
                            </li>
                            <?php 
                                $chapter=mysqli_query($conn01,"select * from coursedetails where courseid =".$_GET['courseid']."");
                                if(mysqli_num_rows($chapter)>0)
                                {
                                while($chapterdetails=mysqli_fetch_array($chapter))
                                {
                            ?>                           
                            <li>
                                <a href="javascript: void(0);">
                                    <i data-feather="file"></i>
                                    <span data-key="t-chapter"><?php echo substr($chapterdetails['chaptername'],0,15); if(strlen($chapterdetails['chaptername'])>15){ echo "...";} ?></span>
                                </a>
                            </li>
                            <li><a href="customer_course-<?php echo $_GET['courseid']?>-summary-<?php echo $chapterdetails['chapter_id'];?>"><i data-feather="file-text"></i>
                                    <span data-key="t-summary">Summary</span></a></li>
                                    <li><a href="customer_course-<?php echo $_GET['courseid']?>-notes-<?php echo $chapterdetails['chapter_id'];?>"><i data-feather="chevrons-right"></i>
                                    <span data-key="t-notes">Notes</span></a></li>
                                    <li><a href="customer_course-<?php echo $_GET['courseid']?>-pptx-<?php echo $chapterdetails['chapter_id'];?>"><i data-feather="chevrons-right"></i>
                                    <span data-key="t-notes">Presentation</span></a></li>
                                    <li><a href="customer_course-<?php echo $_GET['courseid']?>-video-<?php echo $chapterdetails['chapter_id'];?>"><i data-feather="video"></i>
                                    <span data-key="t-video">Video</span></a></li>
                                    <li><a href="customer_course-<?php echo $_GET['courseid']?>-quiz-<?php echo $chapterdetails['chapter_id'];?>" id="quizbtnquizbtn<?php echo $chapterdetails['chapter_id'];?>"><i data-feather="monitor"></i>
                                    <span data-key="t-quiz">Quiz</span></a></li>
                            <?php
                                }
                                }
                            ?>
               

                        </ul>


                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->