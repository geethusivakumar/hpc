            <!-- ========== Left Sidebar Start ========== -->
            <div class="vertical-menu">

                <div data-simplebar class="h-100">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu list-unstyled" id="side-menu">
                            <li class="menu-title" data-key="t-menu">Menu</li>

                            <li>
                                <a href="admindashboard">
                                    <i data-feather="home"></i>
                                    <span data-key="t-dashboard">Dashboard</span>
                                </a>
                            </li>
                            <li>
                                <a href="javascript: void(0);" class="has-arrow">
                                    <i data-feather="lock"></i>
                                    <span data-key="t-profile">My Profile</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    
                                    <li><a href="adminpassword"><i data-feather="key"></i>
                                    <span data-key="t-password">Change Password</span></a></li>
                                   
                                </ul>
                            </li> 
                            <li>
                                <a href="javascript: void(0);" class="has-arrow">
                                    <i data-feather="users"></i>
                                    <span data-key="t-authentication">Users</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    
                                    <li><a href="admin_employees"><i data-feather="user"></i>
                                    <span data-key="t-employee">Employee</span></a></li>
                                    <li><a href="admin_customers"><i data-feather="user"></i>
                                    <span data-key="t-customer">Customer</span></a></li>                                   
                                </ul>
                            </li> 
                            <li>
                                <a href="javascript: void(0);" class="has-arrow">
                                    <i data-feather="book"></i>
                                    <span data-key="t-courses">Courses</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    
                                    <li><a href="admin_courses"><i data-feather="eye"></i>
                                    <span data-key="t-vcourses">View Courses</a></li>
                                    <li><a href="coursetoemployees"><i data-feather="copy"></i>
                                    <span data-key="t-ecourses">Assign Course to Employees</span></a></li>
                                    <li><a href="coursetocustomers"><i data-feather="copy"></i>
                                    <span data-key="t-ccourses">Assign Course to Customers</span></a></li>                                 
                                </ul>
                            </li>
                            <li>
                                <a href="coursechapters">
                                    <i data-feather="file"></i>
                                    <span data-key="t-chapter">Content</span>
                                </a>
                            </li>
                            <li>
                                <a href="javascript: void(0);" class="has-arrow">
                                    <i data-feather="monitor"></i>
                                    <span data-key="t-quiz">Quiz</span>
                                </a>
                                <ul class="sub-menu" aria-expanded="false">
                                    
                                    <li><a href="onlinequiz"><i data-feather="monitor"></i>
                                    <span data-key="ta-quiz">Add Quiz</a></li>
                                    <li><a href="checkquizresults"><i data-feather="monitor"></i>
                                    <span data-key="tr-quiz">Quiz Results</span></a></li>                                
                                </ul>
                            </li>
                            <li>
                                <a href="coursecertificates">
                                    <i data-feather="monitor"></i>
                                    <span data-key="t-cert">Certificates</span>
                                </a>
                            </li>


                            <!-- <li class="menu-title mt-2" data-key="t-components">Elements</li> -->

                           
                        

                        </ul>


                    </div>
                    <!-- Sidebar -->
                </div>
            </div>
            <!-- Left Sidebar End -->