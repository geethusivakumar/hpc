<?php
    $server="localhost";
    $dbuser="root";
    $dbpass="91?t!@A0riK=2E=EmUC3";
    //$dbpass="";
    $dbdatabase="hpc1_admin1";
    $conn01=mysqli_connect($server,$dbuser,$dbpass,$dbdatabase);

    // Check connection
    if (!$conn01) {
        die("Connection failed: " . mysqli_connect_error());
    }
    //echo "Connected successfully";
?>