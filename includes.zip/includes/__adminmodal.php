                    <!--########################## ADD ADMIN PROFILE MODAL ########################## -->  
            
          
             <!--########################## ADD ADMIN PROFILE MODAL  ########################## --> 
        
        
        
        
        <!--########################## EDIT ADMIN PROFILE MODAL ########################## -->  
            
            <!-- The Modal -->
            <div class="modal" id="AdminEdit">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">

                                <!-- Modal Header -->
                                <div class="modal-header">
                                    <h4 class="modal-title">Edit Admin Profile</h4>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>

                                <!-- Modal body -->
                               
                                <div class="modal-body" id="edit_admins">
                                    
                                </div>
                            </div>
                        </div>
                    </div>

             <!--########################## EDIT ADMIN PROFILE MODAL  ########################## --> 